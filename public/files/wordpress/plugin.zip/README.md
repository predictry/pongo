## WoCommerce Client

#### todo
* check the recommendation log 
* debug buy action


