=== Plugin Name ===
Contributors: predictry
Donate link: http://predictry.com
Tags: recommendation, ecommerce
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.

== Description ==

This is the long description.  No limit, and you can use Markdown (as well as in the following sections).

For backwards compatibility, if this section is missing, the full length of the short description will be used, and
Markdown parsed.

== Installation ==

From your WordPress dashboard

1. Visit 'Plugins > Add New'
2. Search for 'predictry'
3. Activate predictry from your Plugins page. 

From WordPress.org

1. Download predictry.
2. Upload the 'predictry' directory to your '/wp-content/plugins/' directory, using your favorite method (ftp, sftp, scp, etc...)
3. Activate predictry from your Plugins page. 

Extra
1. Copy and paste the tenantID from dashboard.preditry.com
2. Copy and paste the secrete key from dashboard.predictry.com

== Frequently Asked Questions ==

= How do I get tenantID and secrete key ==

Go to http://dashboard.predictry.com and sign up for an account with your website url.
Go to Manage Site >> Edit >> and copy paste the tenant ID and secrete key.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets 
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png` 
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 0.1 =
* Add the tracking scripts into wordpress
* Create tracking variables for each actions ( view, buy, checkout )
* Send the log into predictry server

== Arbitrary section ==

`<?php code(); // goes in backticks ?>`
